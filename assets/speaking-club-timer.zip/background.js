chrome.commands.onCommand.addListener((command) => {
  if (command === 'toggle-timer') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, { type: 'TOGGLE_VISIBLE' }, () => {
          // Ignore "receiving end does not exist" — shortcut pressed on a non-Slides tab
          void chrome.runtime.lastError;
        });
      }
    });
  }
});
