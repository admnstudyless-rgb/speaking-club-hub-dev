(function () {
  'use strict';

  // ── State ──────────────────────────────────────────────────────
  let timerInterval  = null;
  let startSeconds   = 5 * 60; // default 5:00
  let seconds        = startSeconds;
  let running        = false;
  let countdown      = true;   // true = count down, false = count up
  let theme          = 'dark';
  let slideData      = {};     // { slideId: { startSeconds, countdown } }
  let currentSlideId = 'default';
  let audioCtx       = null;
  let blinkActive    = false;
  let volume         = 0.4; // 0.0 – 1.0
  let beepCount      = 2;   // 1 | 2 | 3
  let widgetSize     = 'm'; // 's' | 'm' | 'l'

  // Widget position — always tracked as right/top distance from container edges.
  // This avoids any dependency on getBoundingClientRect() which breaks inside
  // CSS-transformed containers (Google Slides presentation mode).
  let widgetRight = 20;
  let widgetTop   = 20;

  // ── Audio ──────────────────────────────────────────────────────
  function getAudioCtx() {
    if (!audioCtx) {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
    return audioCtx;
  }

  function beep() {
    const ctx = getAudioCtx();
    if (ctx.state === 'suspended') ctx.resume();

    // Two short clean tones like Zoom's notification
    function tone(startTime) {
      const osc  = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, startTime);
      gain.gain.setValueAtTime(0, startTime);
      gain.gain.linearRampToValueAtTime(volume, startTime + 0.01);
      gain.gain.setValueAtTime(volume, startTime + 0.12);
      gain.gain.linearRampToValueAtTime(0, startTime + 0.18);
      osc.start(startTime);
      osc.stop(startTime + 0.18);
    }

    for (let i = 0; i < beepCount; i++) {
      tone(ctx.currentTime + i * 0.25);
    }
  }

  // ── Helpers ────────────────────────────────────────────────────
  function fmt(s) {
    const abs = Math.abs(s);
    return (
      String(Math.floor(abs / 60)).padStart(2, '0') +
      ':' +
      String(abs % 60).padStart(2, '0')
    );
  }

  function getSlideId() {
    const m = window.location.href.match(/slide=id\.([^&#?/]+)/);
    return m ? m[1] : 'slide_default';
  }

  // ── Storage ────────────────────────────────────────────────────
  function persist() {
    slideData[currentSlideId] = { startSeconds, countdown };
    chrome.storage.local.set({ slideData, theme, volume, beepCount, widgetSize, widgetRight, widgetTop });
  }

  function loadAll(cb) {
    const keys = ['slideData', 'theme', 'volume', 'beepCount', 'widgetSize',
                  'widgetRight', 'widgetTop',
                  'timerVisible', 'timerRunning', 'timerStartMs',
                  'timerSecondsAtStart', 'timerCountdown', 'timerSecondsSnapshot'];
    chrome.storage.local.get(keys, (res) => {
      if (res.slideData)              slideData   = res.slideData;
      if (res.theme)                  theme       = res.theme;
      if (res.volume !== undefined)   volume      = res.volume;
      if (res.beepCount)              beepCount   = res.beepCount;
      if (res.widgetSize)             widgetSize  = res.widgetSize;
      if (res.widgetRight !== undefined) widgetRight = res.widgetRight;
      if (res.widgetTop   !== undefined) widgetTop   = res.widgetTop;

      // Restore timer state (survives new tab / presentation mode)
      let restoredRunning = false;
      if (res.timerRunning && res.timerStartMs) {
        const elapsed = Math.floor((Date.now() - res.timerStartMs) / 1000);
        const dir     = res.timerCountdown !== false;
        countdown     = dir;
        if (dir) {
          seconds = Math.max(0, (res.timerSecondsAtStart || 0) - elapsed);
        } else {
          seconds = (res.timerSecondsAtStart || 0) + elapsed;
        }
        startSeconds    = res.timerSecondsAtStart || seconds;
        restoredRunning = seconds > 0 || !dir;
      } else if (res.timerSecondsSnapshot !== undefined) {
        seconds = res.timerSecondsSnapshot;
      }

      cb(res.timerVisible !== false, restoredRunning);
    });
  }

  // ── Blink ──────────────────────────────────────────────────────
  function setBlink(on) {
    blinkActive = on;
    const d = document.getElementById('sct-display');
    if (!d) return;
    if (on) d.classList.add('sct-blink');
    else    d.classList.remove('sct-blink');
  }

  // ── Timer logic ────────────────────────────────────────────────
  function tick() {
    if (countdown) {
      seconds = Math.max(0, seconds - 1);
      if (seconds <= 5 && seconds > 0) setBlink(true);
      if (seconds === 0) {
        updateDisplay();
        stopTimer();
        setBlink(false);
        beep();
        return;
      }
    } else {
      seconds++;
    }
    updateDisplay();
  }

  function startTimer() {
    if (running) return;
    const ctx = getAudioCtx();
    if (ctx.state === 'suspended') ctx.resume();
    running       = true;
    timerInterval = setInterval(tick, 1000);
    const btn = document.getElementById('sct-start');
    if (btn) btn.textContent = '⏸';
    // Persist so new tabs (presentation mode) can restore the timer
    chrome.storage.local.set({
      timerRunning: true,
      timerStartMs: Date.now(),
      timerSecondsAtStart: seconds,
      timerCountdown: countdown,
    });
  }

  function pauseTimer() {
    running = false;
    clearInterval(timerInterval);
    const btn = document.getElementById('sct-start');
    if (btn) btn.textContent = '▶';
    chrome.storage.local.set({ timerRunning: false, timerSecondsSnapshot: seconds });
  }

  function stopTimer() {
    pauseTimer();
    setBlink(false);
  }

  function resetTimer() {
    stopTimer();
    seconds = startSeconds;
    updateDisplay();
  }

  function adjustTime(delta) {
    startSeconds = Math.max(0, startSeconds + delta);
    seconds      = running ? Math.max(0, seconds + delta) : startSeconds;
    // Re-evaluate blink state
    if (countdown && running) {
      if (seconds <= 5 && seconds > 0) setBlink(true);
      else setBlink(false);
    }
    updateDisplay();
    persist();
  }

  // ── UI updates ─────────────────────────────────────────────────
  function updateDisplay() {
    const el = document.getElementById('sct-display');
    if (el) el.textContent = fmt(seconds);
  }

  function applyTheme() {
    const w = document.getElementById('sct-widget');
    if (!w) return;
    w.classList.remove('dark', 'light');
    w.classList.add(theme);
    const btn = document.getElementById('sct-theme-btn');
    if (btn) btn.textContent = theme === 'dark' ? '☀️' : '🌙';
  }

function applyDirection() {
    const btn = document.getElementById('sct-dir-btn');
    if (!btn) return;
    
    // Теперь мы всегда выводим полный текст, независимо от размера
    btn.textContent = countdown ? '⬇ Countdown' : '⬆ Count up';
  }

  function applyBeepCount() {
    const toggle = document.getElementById('sct-beep-toggle');
    if (toggle) toggle.textContent = beepCount + '×';
    document.querySelectorAll('.sct-beep-opt').forEach(btn => {
      btn.classList.toggle('active', Number(btn.dataset.v) === beepCount);
    });
  }

  const ZOOM = { s: 0.78, m: 1.0, l: 1.28 };

  function applyPosition() {
    const w = document.getElementById('sct-widget');
    if (!w) return;
    w.style.left   = 'auto';
    w.style.bottom = 'auto';
    w.style.right  = widgetRight + 'px';
    w.style.top    = widgetTop   + 'px';
  }

function clampPosition() {
    const w = document.getElementById('sct-widget');
    if (!w) return;
    const rect = w.getBoundingClientRect();
    const vw   = window.innerWidth;
    const vh   = window.innerHeight;
    const scale = ZOOM[widgetSize] || 1; // Достаем текущий масштаб

    let fix = false;

    // Если вылезли за левый край
    if (rect.left < 0) {
      widgetRight = Math.max(0, widgetRight + (rect.left / scale));
      fix = true;
    }
    // Если вылезли за правый край
    if (rect.right > vw) {
      widgetRight = 0; 
      fix = true;
    }
    // Если вылезли за верхний край
    if (rect.top < 0) {
      widgetTop = 0; 
      fix = true;
    }
    // Если вылезли за нижний край
    if (rect.bottom > vh) {
      widgetTop = Math.max(0, widgetTop - ((rect.bottom - vh) / scale));
      fix = true;
    }

    if (fix) applyPosition();
  }

  function applySize() {
    const w = document.getElementById('sct-widget');
    if (!w) return;
    w.classList.remove('size-s', 'size-m', 'size-l');
    w.classList.add('size-' + widgetSize);
    applyPosition();
    clampPosition();
    const toggle = document.getElementById('sct-size-toggle');
    if (toggle) toggle.textContent = widgetSize.toUpperCase();
    ['s', 'm', 'l'].forEach(s => {
      const btn = document.getElementById('sct-size-' + s);
      if (btn) btn.classList.toggle('active', s === widgetSize);
    });
    applyDirection();
  }

  // ── Slide change ───────────────────────────────────────────────
  function onSlideChange() {
    const id = getSlideId();
    if (id === currentSlideId) return;

    persist();
    currentSlideId = id;

    // Load new slide's reset value silently — never change current display or seconds
    const saved = slideData[id];
    if (saved) {
      startSeconds = saved.startSeconds;
      countdown    = saved.countdown;
      applyDirection();
    }
  }

  // ── Time editor (click on display) ────────────────────────────
  function openEditor() {
    if (running) return; // don't edit while running
    const display = document.getElementById('sct-display');
    if (!display) return;

    let done = false;

    const input = document.createElement('input');
    input.id        = 'sct-time-input';
    input.type      = 'text';
    input.value     = fmt(startSeconds);
    input.maxLength = 5;
    display.replaceWith(input);
    input.focus();
    input.select();

    function commit(save) {
      if (done) return;
      done = true;
      if (save) {
        const parts = (input.value || '').split(':');
        if (parts.length === 2) {
          const m = Math.max(0, parseInt(parts[0]) || 0);
          const s = Math.min(59, Math.max(0, parseInt(parts[1]) || 0));
          startSeconds = m * 60 + s;
          seconds      = startSeconds;
        }
      }
      const newDisplay = document.createElement('div');
      newDisplay.id          = 'sct-display';
      newDisplay.textContent = fmt(seconds);
      newDisplay.addEventListener('click', openEditor);
      if (input.parentNode) input.replaceWith(newDisplay);
      if (save) persist();
    }

    // Stop arrow keys / space from triggering slide navigation
    ['keydown', 'keyup', 'keypress'].forEach((ev) => {
      input.addEventListener(ev, (e) => e.stopPropagation());
    });

    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter')  commit(true);
      if (e.key === 'Escape') commit(false);
    });
    input.addEventListener('blur', () => commit(true));
  }

  // ── Drag (whole widget, except interactive elements) ───────────
  // ── Drag (whole widget, except interactive elements) ───────────
  function initDrag(widget) {
    const SKIP = new Set(['BUTTON', 'INPUT', 'SELECT']);

    widget.addEventListener('pointerdown', (e) => {
      // Игнорируем клики по кнопкам и полям ввода
      if (SKIP.has(e.target.tagName)) return;
      if (e.target.id === 'sct-display') return;
      e.preventDefault();

      // Захватываем курсор и меняем его внешний вид
      widget.setPointerCapture(e.pointerId);
      widget.style.cursor = 'grabbing';
      document.body.style.userSelect = 'none';

      // Запоминаем позицию мыши и виджета в момент начала перетаскивания
      const startX = e.clientX;
      const startY = e.clientY;
      const startWidgetRight = widgetRight;
      const startWidgetTop = widgetTop;
      const scale = ZOOM[widgetSize] || 1;

      // Функция, которая работает, пока мы двигаем мышкой
      const onMove = (ev) => {
        const deltaX = ev.clientX - startX;
        const deltaY = ev.clientY - startY;

        // Вычисляем новые координаты с учетом масштаба (zoom)
        widgetRight = Math.max(0, startWidgetRight - (deltaX / scale));
        widgetTop   = Math.max(0, startWidgetTop + (deltaY / scale));

        applyPosition();
        clampPosition(); // Не даем вылезти за края
      };

      // Функция, которая работает, когда мы отпускаем кнопку мыши
      const onUp = () => {
        // Возвращаем обычный курсор
        widget.style.cursor = 'grab';
        document.body.style.userSelect = '';
        
        // Отключаем слежение за мышкой
        document.removeEventListener('pointermove', onMove);
        document.removeEventListener('pointerup',   onUp);
        document.removeEventListener('pointercancel', onUp);

        // 🌟 ИСПРАВЛЕНИЕ ЗДЕСЬ: Сохраняем новые координаты в память браузера!
        persist();
      };
      
      // Начинаем следить за движением и отпусканием мыши
      document.addEventListener('pointermove', onMove);
      document.addEventListener('pointerup',   onUp);
      document.addEventListener('pointercancel', onUp);
    });
  }

  // ── Build widget ───────────────────────────────────────────────
  function buildWidget() {
    const w = document.createElement('div');
    w.id        = 'sct-widget';
    w.className = theme;
    w.innerHTML = `
      <div id="sct-header">
        <button id="sct-dir-btn" class="sct-small-btn">⬇ Countdown</button>
        <div id="sct-right-controls">
          <div id="sct-beep-wrap">
            <button id="sct-beep-toggle" class="sct-small-btn">${beepCount}×</button>
            <div id="sct-beep-dropdown">
              <button class="sct-beep-opt" data-v="1">1×</button>
              <button class="sct-beep-opt" data-v="2">2×</button>
              <button class="sct-beep-opt" data-v="3">3×</button>
            </div>
          </div>
          <div id="sct-size-wrap">
            <button id="sct-size-toggle" class="sct-small-btn">${widgetSize.toUpperCase()}</button>
            <div id="sct-size-dropdown">
              <button id="sct-size-s" class="sct-size-opt">S</button>
              <button id="sct-size-m" class="sct-size-opt">M</button>
              <button id="sct-size-l" class="sct-size-opt">L</button>
            </div>
          </div>
          <button id="sct-theme-btn" class="sct-small-btn">☀️</button>
        </div>
      </div>
      <div id="sct-display">${fmt(seconds)}</div>
      <div id="sct-adj-row">
        <button id="sct-minus" class="sct-adj-btn">−30s</button>
        <button id="sct-plus"  class="sct-adj-btn">+30s</button>
      </div>
      <div id="sct-btn-row">
        <button id="sct-start"     class="sct-ctrl-btn">▶</button>
        <button id="sct-reset-btn" class="sct-ctrl-btn">↺</button>
      </div>
      <div id="sct-volume-row">
        <span class="sct-vol-icon">🔈</span>
        <input id="sct-volume" type="range" min="0" max="1" step="0.05" value="${volume}">
        <span class="sct-vol-icon">🔊</span>
      </div>
    `;
    w.style.cssText = 'position:fixed;top:20px;right:20px;z-index:2147483647!important;';
    const fs = document.fullscreenElement || document.webkitFullscreenElement;
    (fs || document.documentElement).appendChild(w);

    // Wire up events
    document.getElementById('sct-start').addEventListener('click', () => {
      running ? pauseTimer() : startTimer();
    });
    document.getElementById('sct-reset-btn').addEventListener('click', resetTimer);
    document.getElementById('sct-minus').addEventListener('click', () => adjustTime(-30));
    document.getElementById('sct-plus').addEventListener('click',  () => adjustTime(30));
    document.getElementById('sct-display').addEventListener('click', openEditor);

    document.getElementById('sct-theme-btn').addEventListener('click', () => {
      theme = theme === 'dark' ? 'light' : 'dark';
      applyTheme();
      persist();
    });

    document.getElementById('sct-dir-btn').addEventListener('click', () => {
      countdown = !countdown;
      applyDirection();
      if (!running) { seconds = startSeconds; updateDisplay(); }
      persist();
    });

    const volSlider = document.getElementById('sct-volume');
    volSlider.addEventListener('input', () => {
      volume = parseFloat(volSlider.value);
      persist();
    });
    ['keydown', 'keyup'].forEach(ev => volSlider.addEventListener(ev, e => e.stopPropagation()));

    // Beep count dropdown
    const beepToggle   = document.getElementById('sct-beep-toggle');
    const beepDropdown = document.getElementById('sct-beep-dropdown');
    beepToggle.addEventListener('click', (e) => {
      e.stopPropagation();
      beepDropdown.classList.toggle('open');
    });
    document.querySelectorAll('.sct-beep-opt').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        beepCount = Number(btn.dataset.v);
        applyBeepCount();
        persist();
        beepDropdown.classList.remove('open');
      });
    });
    document.addEventListener('click', () => beepDropdown.classList.remove('open'));

    // Size dropdown
    const sizeToggle   = document.getElementById('sct-size-toggle');
    const sizeDropdown = document.getElementById('sct-size-dropdown');
    
    sizeToggle.addEventListener('click', (e) => {
      e.stopPropagation();
      sizeDropdown.classList.toggle('open');
    });
    
    ['s', 'm', 'l'].forEach(s => {
      document.getElementById('sct-size-' + s).addEventListener('click', (e) => {
        e.stopPropagation();
        
        // 🌟 ИСПРАВЛЕНИЕ ЗДЕСЬ: Компенсируем прыжок координат перед сменой размера
        if (widgetSize !== s) {
          const oldScale = ZOOM[widgetSize] || 1;
          const newScale = ZOOM[s] || 1;
          
          // Пропорционально меняем отступы
          widgetRight = widgetRight * (oldScale / newScale);
          widgetTop   = widgetTop * (oldScale / newScale);
        }
        
        widgetSize = s;
        applySize();
        persist();
        sizeDropdown.classList.remove('open');
      });
    });
    
    document.addEventListener('click', () => sizeDropdown.classList.remove('open'));
    document.addEventListener('click', () => sizeDropdown.classList.remove('open'));

    // Messages from popup (SET_VISIBLE) and background (TOGGLE_VISIBLE)
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg.type === 'SET_VISIBLE') {
        w.style.display = msg.visible ? '' : 'none';
        chrome.storage.local.set({ timerVisible: msg.visible });
      }
      if (msg.type === 'TOGGLE_VISIBLE') {
        const visible = w.style.display === 'none';
        w.style.display = visible ? '' : 'none';
        chrome.storage.local.set({ timerVisible: visible });
      }
    });

    initDrag(w);
    return w;
  }

  // ── Init ───────────────────────────────────────────────────────
  function init() {
    if (document.getElementById('sct-widget')) return;

    currentSlideId = getSlideId();
    const saved    = slideData[currentSlideId];
    if (saved) {
      startSeconds = saved.startSeconds;
      // Don't overwrite countdown/seconds if restored from running state
      if (!running) {
        countdown = saved.countdown;
        seconds   = startSeconds;
      }
    }

    const w = buildWidget();
    applyTheme();
    applySize();
    applyBeepCount();

    function getTarget() {
      return document.fullscreenElement || document.webkitFullscreenElement || document.documentElement;
    }

    function reattach() {
      const target = getTarget();
      if (w.parentElement !== target) target.appendChild(w);
    }

    // Move widget when fullscreen state changes
    document.addEventListener('fullscreenchange',       reattach);
    document.addEventListener('webkitfullscreenchange', reattach);

    // Detect slide navigation + keep widget in correct container
    let lastHref = window.location.href;
    setInterval(() => {
      if (window.location.href !== lastHref) {
        lastHref = window.location.href;
        onSlideChange();
      }
      // Always ensure widget is in the right container (handles delayed fullscreen entry)
      reattach();
    }, 400);
      // Возвращаем виджет на экран, если окно браузера изменило размер
    window.addEventListener('resize', () => {
      clampPosition();
    });
    window.addEventListener('hashchange', onSlideChange);
  }

  // ── Boot ───────────────────────────────────────────────────────
  loadAll((initiallyVisible, restoredRunning) => {
    function tryInit() {
      init();
      const w = document.getElementById('sct-widget');
      if (w && !initiallyVisible) w.style.display = 'none';
      // Resume timer if it was running before the tab change
      if (restoredRunning) startTimer();
    }
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', tryInit);
    } else {
      setTimeout(tryInit, 1500);
    }
  });

})();
