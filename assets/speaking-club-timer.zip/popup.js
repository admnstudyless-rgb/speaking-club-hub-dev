const btn = document.getElementById('toggle-btn');
let visible = true;

// Load current state
chrome.storage.local.get(['timerVisible'], (res) => {
  visible = res.timerVisible !== false; // default: visible
  render();
});

function render() {
  if (visible) {
    btn.textContent = '👁 Timer is on';
    btn.className = 'visible';
  } else {
    btn.textContent = '🙈 Timer is off';
    btn.className = 'hidden';
  }
}

btn.addEventListener('click', () => {
  visible = !visible;
  chrome.storage.local.set({ timerVisible: visible });
  render();

  // Send message to the active Google Slides tab
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]) {
      chrome.tabs.sendMessage(tabs[0].id, { type: 'SET_VISIBLE', visible })
        .catch(() => {}); // ignore if tab has no content script
    }
  });
});
